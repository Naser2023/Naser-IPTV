package com.naser.iptv

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private val executor = Executors.newSingleThreadExecutor()
    private var xtream: Xtream? = null
    private var section = "Live TV"
    private var categories = listOf<XtreamCategory>()
    private var items = listOf<XtreamItem>()
    private var visibleItems = listOf<XtreamItem>()
    private val favorites = mutableSetOf<String>()

    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var list: ListView
    private lateinit var search: EditText
    private lateinit var categorySpinner: Spinner
    private lateinit var favoriteOnly: CheckBox
    private lateinit var tabs: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("account", MODE_PRIVATE)
        val server = prefs.getString("server", null)
        val user = prefs.getString("user", null)
        val pass = prefs.getString("pass", null)
        favorites.addAll(getSharedPreferences("favorites", MODE_PRIVATE).getStringSet("ids", emptySet()) ?: emptySet())
        if (server != null && user != null && pass != null) {
            xtream = Xtream(server, user, pass)
            showHome()
        } else showLogin()
    }

    private fun background(view: View, color: Int, radius: Float = 16f) {
        view.background = GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius
        }
    }

    private fun page() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 8)
            setBackgroundColor(Color.rgb(12, 14, 24))
        }
        setContentView(root)
    }

    private fun label(value: String, size: Float = 15f, color: Int = Color.WHITE) = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        setPadding(5, 7, 5, 7)
    }

    private fun input(hintValue: String) = EditText(this).apply {
        hint = hintValue
        setHintTextColor(0xFF9296AA.toInt())
        setTextColor(Color.WHITE)
        setSingleLine(true)
        textSize = 15f
        setPadding(16, 8, 16, 8)
        background(this, 0xFF202438.toInt(), 18f)
    }

    private fun showLogin() {
        page()
        root.gravity = Gravity.CENTER_VERTICAL
        root.addView(label("NASER IPTV", 32f))
        root.addView(label("Your entertainment, in one place", 14f, 0xFF9DA3B8.toInt()))
        val server = input("Server URL  https://example.com:8080")
        val username = input("Username")
        val password = input("Password").apply { inputType = 129 }
        val message = label("")
        root.addView(server); root.addView(username); root.addView(password)
        root.addView(Button(this).apply {
            text = "CONNECT"
            setOnClickListener {
                val base = server.text.toString().trim().trimEnd('/')
                val u = username.text.toString().trim()
                val p = password.text.toString()
                if (base.isBlank() || u.isBlank() || p.isBlank()) {
                    message.text = "Enter all account details"; return@setOnClickListener
                }
                message.text = "Connecting…"
                executor.execute {
                    try {
                        val client = Xtream(base, u, p)
                        val valid = client.authenticate()
                        runOnUiThread {
                            if (valid) {
                                xtream = client
                                getSharedPreferences("account", MODE_PRIVATE).edit()
                                    .putString("server", base).putString("user", u).putString("pass", p).apply()
                                showHome()
                            } else message.text = "Login failed. Verify your credentials."
                        }
                    } catch (e: Exception) {
                        runOnUiThread { message.text = "Connection failed: ${e.message}" }
                    }
                }
            }
        })
        root.addView(message)
        val prefs = getSharedPreferences("account", MODE_PRIVATE)
        server.setText(prefs.getString("server", ""))
        username.setText(prefs.getString("user", ""))
        password.setText(prefs.getString("pass", ""))
    }

    private fun showHome() {
        page()
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        brand.addView(label("NASER IPTV", 24f))
        brand.addView(label("LIVE  •  MOVIES  •  SERIES", 10f, 0xFF8D94AE.toInt()))
        header.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(Button(this).apply { text = "Account"; setOnClickListener { showAccountDialog() } })
        root.addView(header)

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 12, 16, 12)
            background(this, 0xFF292D52.toInt(), 20f)
        }
        hero.addView(label("WELCOME BACK", 11f, 0xFFB7BCE0.toInt()))
        hero.addView(label("Choose what you want to watch", 18f))
        root.addView(hero)

        tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 8, 0, 4) }
        listOf("Live TV", "Movies", "Series").forEach { tab ->
            tabs.addView(Button(this).apply {
                text = tab
                setOnClickListener {
                    section = tab
                    updateTabStyles()
                    loadCategories()
                }
            }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(tabs)
        updateTabStyles()

        categorySpinner = Spinner(this)
        root.addView(categorySpinner)
        search = input("Search channels, movies and series")
        root.addView(search)
        favoriteOnly = CheckBox(this).apply {
            text = "Favourites"
            setTextColor(0xFFE9EAF2.toInt())
            buttonTintList = android.content.res.ColorStateList.valueOf(0xFF7C83FF.toInt())
            setOnCheckedChangeListener { _, _ -> filterAndDisplay() }
        }
        root.addView(favoriteOnly)
        status = label("Loading categories…", 12f, 0xFF9DA3B8.toInt())
        root.addView(status)
        list = ListView(this).apply {
            divider = null
            dividerHeight = 8
            setBackgroundColor(Color.TRANSPARENT)
            clipToPadding = false
            setPadding(0, 4, 0, 12)
        }
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))

        categorySpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (categories.isNotEmpty()) loadItems()
            }
        }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = filterAndDisplay()
            override fun afterTextChanged(s: Editable?) {}
        })
        list.setOnItemClickListener { _, _, position, _ ->
            val item = visibleItems.getOrNull(position) ?: return@setOnItemClickListener
            if (item.kind == "series") loadEpisodes(item)
            else startActivity(Intent(this, PlayerActivity::class.java)
                .putExtra("url", item.streamUrl).putExtra("title", item.name)
                .putExtra("streamId", if (item.kind == "live") item.id else ""))
        }
        list.setOnItemLongClickListener { _, _, position, _ ->
            val item = visibleItems.getOrNull(position) ?: return@setOnItemLongClickListener true
            val key = "${item.kind}:${item.id}"
            if (favorites.contains(key)) favorites.remove(key) else favorites.add(key)
            getSharedPreferences("favorites", MODE_PRIVATE).edit().putStringSet("ids", favorites).apply()
            filterAndDisplay()
            Toast.makeText(this, if (favorites.contains(key)) "Added to favourites" else "Removed from favourites", Toast.LENGTH_SHORT).show()
            true
        }
        loadCategories()
    }

    private fun updateTabStyles() {
        if (!::tabs.isInitialized) return
        for (i in 0 until tabs.childCount) {
            val button = tabs.getChildAt(i) as Button
            val selected = button.text.toString() == section
            button.setTextColor(if (selected) Color.WHITE else 0xFFADB2C5.toInt())
            button.backgroundTintList = android.content.res.ColorStateList.valueOf(
                if (selected) 0xFF5C63E8.toInt() else 0xFF202438.toInt()
            )
        }
    }

    private fun showAccountDialog() {
        val prefs = getSharedPreferences("account", MODE_PRIVATE)
        android.app.AlertDialog.Builder(this)
            .setTitle("Account")
            .setMessage("Server: ${prefs.getString("server", "")}\nUser: ${prefs.getString("user", "")}")
            .setNegativeButton("Close", null)
            .setPositiveButton("Log out") { _, _ ->
                prefs.edit().clear().apply()
                xtream = null
                showLogin()
            }.show()
    }

    private fun loadCategories() {
        status.text = "Loading $section categories…"
        executor.execute {
            try {
                val result = xtream!!.categories(section)
                runOnUiThread {
                    categories = listOf(XtreamCategory("all", "All categories")) + result
                    categorySpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, categories.map { it.name })
                    loadItems()
                }
            } catch (e: Exception) { runOnUiThread { status.text = "Category error: ${e.message}" } }
        }
    }

    private fun loadItems() {
        if (categories.isEmpty()) return
        val selected = categories.getOrNull(categorySpinner.selectedItemPosition)?.id ?: "all"
        status.text = "Loading $section…"
        executor.execute {
            try {
                val result = xtream!!.items(section, selected)
                runOnUiThread {
                    items = result
                    filterAndDisplay()
                    status.text = "${result.size} items · Long press to add a favourite"
                }
            } catch (e: Exception) { runOnUiThread { status.text = "Content error: ${e.message}" } }
        }
    }

    private fun filterAndDisplay() {
        if (!::list.isInitialized) return
        val query = search.text.toString()
        visibleItems = items.filter {
            it.name.contains(query, true) && (!favoriteOnly.isChecked || favorites.contains("${it.kind}:${it.id}"))
        }
        list.adapter = ContentAdapter()
    }

    private inner class ContentAdapter : android.widget.BaseAdapter() {
        override fun getCount() = visibleItems.size
        override fun getItem(position: Int) = visibleItems[position]
        override fun getItemId(position: Int) = position
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val item = getItem(position)
            val row = convertView as? LinearLayout ?: LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(10, 9, 10, 9)
                background(this, 0xFF1B1F30.toInt(), 16f)
            }
            row.removeAllViews()
            val image = ImageView(this@MainActivity).apply {
                layoutParams = LinearLayout.LayoutParams(76, 66)
                scaleType = ImageView.ScaleType.CENTER_CROP
                background(this, 0xFF30354B.toInt(), 12f)
            }
            if (item.icon.isNotBlank()) Glide.with(this@MainActivity).load(item.icon)
                .placeholder(android.R.drawable.ic_media_play).error(android.R.drawable.ic_media_play).into(image)
            else image.setImageResource(android.R.drawable.ic_media_play)
            row.addView(image)
            val textColumn = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(12, 0, 4, 0)
            }
            textColumn.addView(label(item.name, 14f))
            textColumn.addView(label(
                when (item.kind) { "live" -> "LIVE CHANNEL"; "movie" -> "MOVIE"; else -> "SERIES" },
                10f, 0xFF8F96B3.toInt()
            ))
            row.addView(textColumn, LinearLayout.LayoutParams(0, -2, 1f))
            if (favorites.contains("${item.kind}:${item.id}")) row.addView(label("★", 20f, 0xFFFFD166.toInt()))
            return row
        }
    }

    private fun loadEpisodes(series: XtreamItem) {
        status.text = "Loading episodes…"
        executor.execute {
            try {
                val episodes = xtream!!.seriesEpisodes(series.id)
                runOnUiThread {
                    if (episodes.isEmpty()) { status.text = "No episodes returned"; return@runOnUiThread }
                    android.app.AlertDialog.Builder(this).setTitle(series.name)
                        .setItems(episodes.map { it.name }.toTypedArray()) { _, which ->
                            val episode = episodes[which]
                            startActivity(Intent(this, PlayerActivity::class.java)
                                .putExtra("url", episode.streamUrl).putExtra("title", episode.name))
                        }.setNegativeButton("Close", null).show()
                    status.text = "${episodes.size} episodes"
                }
            } catch (e: Exception) { runOnUiThread { status.text = "Episode error: ${e.message}" } }
        }
    }
}
