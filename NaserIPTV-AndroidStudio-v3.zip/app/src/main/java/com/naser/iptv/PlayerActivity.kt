package com.naser.iptv

import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.exoplayer2.C
import com.google.android.exoplayer2.DefaultLoadControl
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector
import com.google.android.exoplayer2.trackselection.TrackSelectionDialogBuilder
import com.google.android.exoplayer2.ui.PlayerView
import java.util.concurrent.Executors

class PlayerActivity : AppCompatActivity() {
    private var player: ExoPlayer? = null
    private lateinit var trackSelector: DefaultTrackSelector
    private val executor = Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF10111A.toInt())
        }
        val controls = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(6, 4, 6, 4)
        }
        val title = TextView(this).apply {
            text = intent.getStringExtra("title") ?: "Playing"
            textSize = 14f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(8, 8, 4, 8)
        }
        controls.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        controls.addView(Button(this).apply {
            text = "Audio"
            setOnClickListener { showTrackSelection(C.TRACK_TYPE_AUDIO, "Audio tracks") }
        })
        controls.addView(Button(this).apply {
            text = "Subtitles"
            setOnClickListener { showTrackSelection(C.TRACK_TYPE_TEXT, "Subtitles") }
        })
        controls.addView(Button(this).apply {
            text = "EPG"
            setOnClickListener { showEpg() }
        })
        container.addView(controls)

        val view = PlayerView(this).apply { useController = true; setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS) }
        container.addView(view, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(container)

        trackSelector = DefaultTrackSelector(this)
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(20_000, 60_000, 1_500, 3_000)
            .build()
        player = ExoPlayer.Builder(this)
            .setTrackSelector(trackSelector)
            .setLoadControl(loadControl)
            .build().also {
                view.player = it
                val url = intent.getStringExtra("url") ?: return@also
                it.setMediaItem(MediaItem.fromUri(url))
                it.prepare()
                it.playWhenReady = true
            }
        if (intent.getStringExtra("streamId").isNullOrBlank()) {
            controls.getChildAt(3).isEnabled = false
        }
    }

    private fun showTrackSelection(trackType: Int, title: String) {
        val exo = player ?: return
        val info = trackSelector.currentMappedTrackInfo ?: run {
            Toast.makeText(this, "Track information is not available yet", Toast.LENGTH_SHORT).show()
            return
        }
        val renderer = (0 until info.rendererCount).firstOrNull { info.getRendererType(it) == trackType }
        if (renderer == null) {
            Toast.makeText(this, "No $title available for this stream", Toast.LENGTH_SHORT).show()
            return
        }
        TrackSelectionDialogBuilder(this, title, trackSelector, renderer)
            .setShowDisableOption(trackType == C.TRACK_TYPE_TEXT)
            .build()
            .show()
    }

    private fun showEpg() {
        val prefs = getSharedPreferences("account", MODE_PRIVATE)
        val base = prefs.getString("server", null) ?: return
        val user = prefs.getString("user", null) ?: return
        val pass = prefs.getString("pass", null) ?: return
        val streamId = intent.getStringExtra("streamId") ?: return
        Toast.makeText(this, "Loading programme guide…", Toast.LENGTH_SHORT).show()
        executor.execute {
            try {
                val entries = Xtream(base, user, pass).epg(streamId)
                runOnUiThread {
                    android.app.AlertDialog.Builder(this)
                        .setTitle("Electronic Programme Guide")
                        .setItems(entries.toTypedArray(), null)
                        .setPositiveButton("Close", null).show()
                }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "EPG unavailable: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }
    }

    override fun onStop() {
        super.onStop()
        player?.release()
        player = null
    }
}
