package com.naser.iptv

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

data class XtreamCategory(val id: String, val name: String)
data class XtreamItem(
    val id: String,
    val name: String,
    val streamUrl: String,
    val kind: String,
    val categoryId: String = "",
    val icon: String = ""
)

class Xtream(private val base: String, private val user: String, private val pass: String) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(35, TimeUnit.SECONDS)
        .build()

    private fun enc(value: String) = URLEncoder.encode(value, "UTF-8")

    private fun get(url: String): String {
        val request = Request.Builder().url(url).header("User-Agent", "NaserIPTV/1.0").build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("HTTP ${response.code}")
            return response.body?.string() ?: "[]"
        }
    }

    private fun api(action: String? = null, extra: String = ""): String {
        val suffix = buildString {
            append("?username=${enc(user)}&password=${enc(pass)}")
            if (!action.isNullOrBlank()) append("&action=${enc(action)}")
            if (extra.isNotBlank()) append("&$extra")
        }
        return get("$base/player_api.php$suffix")
    }

    fun authenticate(): Boolean {
        val json = JSONObject(api())
        val info = json.optJSONObject("user_info") ?: return false
        return info.optString("auth") == "1" &&
            !info.optString("status").equals("Disabled", true)
    }

    fun categories(section: String): List<XtreamCategory> {
        val action = when (section) {
            "Live TV" -> "get_live_categories"
            "Movies" -> "get_vod_categories"
            else -> "get_series_categories"
        }
        val arr = JSONArray(api(action))
        return (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            XtreamCategory(o.optString("category_id"), o.optString("category_name", "Other"))
        }
    }

    fun items(section: String, categoryId: String? = null): List<XtreamItem> {
        val (action, kind) = when (section) {
            "Live TV" -> "get_live_streams" to "live"
            "Movies" -> "get_vod_streams" to "movie"
            else -> "get_series" to "series"
        }
        val extra = if (!categoryId.isNullOrBlank() && categoryId != "all")
            "category_id=${enc(categoryId)}" else ""
        val arr = JSONArray(api(action, extra))
        return (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            val id = o.optString(if (kind == "series") "series_id" else "stream_id")
            val name = o.optString("name", "Untitled")
            val extension = o.optString("container_extension", if (kind == "live") "ts" else "mp4")
            val url = when (kind) {
                "live" -> "$base/$user/$pass/$id.$extension"
                "movie" -> "$base/movie/$user/$pass/$id.$extension"
                else -> ""
            }
            XtreamItem(
                id, name, url, kind,
                o.optString("category_id"),
                o.optString("stream_icon", o.optString("cover"))
            )
        }
    }

    fun seriesEpisodes(seriesId: String): List<XtreamItem> {
        val json = JSONObject(api("get_series_info", "series_id=${enc(seriesId)}"))
        val episodes = json.optJSONObject("episodes") ?: return emptyList()
        val result = mutableListOf<XtreamItem>()
        val seasons = episodes.keys()
        while (seasons.hasNext()) {
            val season = seasons.next()
            val arr = episodes.optJSONArray(season) ?: continue
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val id = o.optString("id")
                val ext = o.optString("container_extension", "mp4")
                val title = o.optString("title", "Episode ${i + 1}")
                result += XtreamItem(id, "Season $season · $title",
                    "$base/series/$user/$pass/$id.$ext", "episode")
            }
        }
        return result
    }

    fun epg(streamId: String): List<String> {
        val json = JSONObject(api("get_short_epg", "stream_id=${enc(streamId)}&limit=10"))
        val arr = json.optJSONArray("epg_listings") ?: return emptyList()
        return (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            val title = o.optString("title").let {
                try { String(android.util.Base64.decode(it, android.util.Base64.DEFAULT)) }
                catch (_: Exception) { it }
            }
            val start = o.optString("start")
            val end = o.optString("end")
            "$start – $end  $title"
        }
    }
}
