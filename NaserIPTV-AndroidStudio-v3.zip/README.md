# Naser IPTV V3

## New in V3
- Redesigned dark dashboard and section tabs
- Channel logos and movie/series artwork loaded from provider image URLs
- Category filters, search, and favourites
- Series episode selection and playback
- ExoPlayer internal playback
- Audio and subtitle track selection dialogs
- Larger configurable playback buffer
- Short EPG lookup for supported live streams

## Build
Open this directory in Android Studio with JDK 17. Sync Gradle, then Build > Build APK(s).

## Limitations and security
This is source code, not a verified APK. It has not been compiled or tested against a live IPTV provider here.
Xtream API behavior and image URLs vary by provider. Use only services and streams you are authorized to access.
Credentials are still stored in SharedPreferences in this prototype. Use Android Keystore-backed encryption before release.
Buffer tuning cannot guarantee a stutter-free stream; server capacity, network quality, and stream format matter.
